class stack:
    def __init__(self):
        self.items = []
    def push (self, a):
        self.items.append(a)
    def pop(self):
        try:
         return self.items.pop()
        except IndexError:
         return None
    def peek(self):
        try:
             return self.items[-1]
        except IndexError:
             return None   
    def size(self):
        return len(self.items)