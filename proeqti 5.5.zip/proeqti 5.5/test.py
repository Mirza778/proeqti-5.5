
from stack import Stack
from queue import Queue
stack = Stack()
print("სტეკის ტესტირება:")

for i in range(1, 6):
    stack.push(i)
print("სტეკში დამატებული ელემენტები:", stack.items)

for _ in range(3):
    popped = stack.pop()
    print(f"ამოღებულია: {popped}")

print("სტეკის თავში მყოფი ელემენტი (peek):", stack.peek())
print("სტეკის ზომა:", stack.size())
print("სტეკი ცარიელია?", stack.is_empty())
print("-" * 40)

queue = Queue()
print("რიგის ტესტირება:")

for i in range(1, 6):
    queue.enqueue(i)
print("რიგში დამატებული ელემენტები:", queue.items)

for _ in range(2):
    dequeued = queue.dequeue()
    print(f"ამოღებულია: {dequeued}")
print("რიგის პირველი ელემენტი (front):", queue.front())
print("რიგის ზომა:", queue.size())
print("რიგი ცარიელია?", queue.is_empty())

