class Queue:
    def __init__(self):
        self.items = []
    def enqueue(self, item):
        self.items.append(item)
    def dequeue(self):
      try:
        return self.items.pop(0)
      except IndexError:
        return None
    def front(self):
      try:
        return self.items[0]
      except IndexError:
        return None
    def size(self):
        """აბრუნებს ელემენტების რაოდენობას"""
        return len(self.items)